﻿using Microsoft.EntityFrameworkCore;

namespace RestaurantAPI.Models
{
    public class RestaurantReservationContext : DbContext
    {
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Restaurant> Restaurants { get; set; }
        public DbSet<RestaurantDetail> RestaurantDetails { get; set; }
        public DbSet<Cuisine> Cuisines { get; set; }
        public DbSet<Reservation> Reservation { get; set; }


        public RestaurantReservationContext(DbContextOptions<RestaurantReservationContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().ToTable("Customer");
            modelBuilder.Entity<Restaurant>().ToTable("Restaurant");
            modelBuilder.Entity<RestaurantDetail>().ToTable("RestaurantDetail");
            modelBuilder.Entity<Cuisine>().ToTable("Cuisine");
            modelBuilder.Entity<Reservation>().ToTable("Reservation");
        }
    }
}
