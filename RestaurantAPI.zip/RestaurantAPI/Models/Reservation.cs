﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RestaurantAPI.Models
{
    public class Reservation
    {
        [Key]
        public long BookingId { get; set; }
        public long Occupants { get; set; }
        public long RestaurantId { get; set; }
        public long CustomerId { get; set; }
        public string CuisineName { get; set; }
    }

}
