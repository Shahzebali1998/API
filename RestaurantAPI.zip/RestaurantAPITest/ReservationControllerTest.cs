﻿using System;
using NUnit.Framework;
using Microsoft.AspNetCore.Mvc;
using RestaurantAPI.Controllers;
using RestaurantAPI.Models;

namespace RestaurantAPITest
{

    [TestFixture]
    public class ReservationsControllers : Controller
    {
        public ActionResult Index()
        {
            // Add action logic here
            throw new NotImplementedException();
        }

        public ActionResult Details(int Id)
        {

            return View("Details");
        }
    }


    [TestFixture]
    public class ReservationsControllerTest1
    {
        [Test]
        public void TestDetailsView()
        {
            var controller = new ReservationsControllers();
            var result = controller.Details(2) as ViewResult;
            Assert.AreEqual("Details", result.ViewName);

        }
    }

    [TestFixture]
    public class ReservationsControllersTest2
    {
        [Test]
        public void TestDetailsView()
        {
            var controller = new ReservationsControllers();
            var result = controller.Details(3) as ViewResult;
            Assert.IsEmpty("", result.ViewName);





        }
        [TestFixture]
        public class ReservationsControllerTest3
        {
            [Test]
            public void TestDetailsView()
            {
                var controller = new ReservationsControllers();
                var result = controller.Details(3) as ViewResult;
                Assert.IsNaN(double.NaN, result.ViewName);





            }
        }
        [TestFixture]
        public class ReservationsControllerTest4
        {
            [Test]
            public void TestDetailsView()
            {
                var controller = new ReservationsControllers();
                var result = controller.Details(3) as ViewResult;
                Assert.NotNull("Passed", result.ViewName);





            }
        }
    }
}
